<?php require_once ("session.php")?>
<?php require_once ("database_connect.php")?>
<?php require_once ("functions.php")?>

<?php
	$admin = find_admin_by_id($_GET["id"]);
	if (!$admin){redirect_to("manage_admins.php");}
?>

<?php
if (isset($_POST['submit'])){
	$req_fields = array("username","password");
	validate_presences ($req_fields);
	
	$fieldmaxL = array ($username = 30);
	validate_max_lengths($fields_with_max_lengts);
	
	if (empty($errors)){
		$username			= mysqli_prepare($_POST["username"]);
		$hashed_password	= mysqli_prepare($_POST["password"]);
		
		$query	=	"DELETE FROM admins ";
		$query	.=	"WHERE id = {$id} ";
		$query	.=	"LIMIT 1";
	
		$result = mysqli_query($connection, $query);
		
		if ($result) {$_SESSION["message"] = "Admin deleted.";
		redirect_to("manage_admins.php");}//sucsess
		else {$_SESSION["message"] = "Admin deletion failed.";}}}
else {}
?>
