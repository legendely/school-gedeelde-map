<?php require_once ("session.php")?>
<?php require_once ("database_connect.php")?>
<?php require_once ("functions.php")?>

<?php
$username = "";

if (isset($_POST['submit'])){
	
	$required_fields = array("username","password");
	validate_presences($required_fields);
	
	if (empty($errors)){
		//attempt login	
		$username = $_POST["username"];
		$password = $_POST["password"];
		
		$foundadmin = attempt_login($username, $password);
		
		$_SESSION["admin_id"] = $found_admin["id"];
		$_SESSION["username"] = $found_admin["username"];
		
		if ($foundadmin) {redirect_to("admin.php");}
		// success, gebruiker als ingelogd beschouwen
		else {$_SESSION["message"] = "your password and or username are incorrect";}}}
?>

<table width="500" border="1" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
<tr>
	<form method="post" action="loginlynda.php">
	<td>
		<table width="100%" border="1" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
	<tr><td colspan="3"><strong>Login </strong></td></tr>
	<tr>
		<td width="60">Username</td>
		<td width="10">:</td>
		<td width="300"><input name="username" type="text" value="<?php echo htmlentities($username);?>"></td>
	</tr>
	<tr>
		<td>Password</td>
		<td>:</td>
		<td><input name="password" type="password" value=""></td>
	</tr>
	<tr>
		<td>&nbsp;</td><td>&nbsp;</td>
		<td><input type="submit" name="Submit" value="submit"></td>
	</tr>
</table></td></form></tr></table>



