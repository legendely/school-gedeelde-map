<?php
function redirect_to($new_location)
{header("location: " . $new_location); 
exit;}

function mysql_escstr($string){
	$escstr = mysqli_real_escape_string($connection, $string);
	return $escstr;}

function confirm_query($result_set){
	if (!$result_set){ die("Database query failed."); }}

function find_all_subjects (){
	global $connection;			
		$query = 	"SELECT * ";
		$query .= 	"FROM subjects ";
		//$query .= 	"WHERE visible = 1 ";
		$query .= 	"ORDER BY position ASC";
		$result = mysqli_query($connection, $query);
		confirm_query($subject_set);
		return $subject_set;}

function find_pages_for_subject ($subject_id){
	global $connection;	
		$escstr_subject_id	= mysqli_real_escape_string($connection, $subject_id);		
		$query = 	"SELECT * ";
		$query .= 	"FROM subjects ";
		$query .= 	"WHERE visible = 1 ";
		$query .= 	"AND subject_id = {$escstr_subject_id} ";
		$query .= 	"ORDER BY position ASC";
		$page_set = mysqli_query($connection, $query);
		confirm_query($page_set);
		return $page_set;}

function find_subject_by_id (){
	global $connection;
		$escstr_subject_id	= mysqli_real_escape_string($connection, $subject_id);
		$query = 	"SELECT * ";
		$query .= 	"FROM subjects ";
		$query .= 	"WHERE id = {$escstr_subject_id} ";
		$query .= 	"LIMIT 1";
		$result = mysqli_query($connection, $query);
		confirm_query($subject_set);
		if($subject = mysqli_fetch_assoc($subject_set)){return $subject_set;}
		else {return null;}}

function find_page_by_id (){
	global $connection;
		$escstr_page_id	= mysqli_real_escape_string($connection, $subject_id);
		$query = 	"SELECT * ";
		$query .= 	"FROM pages ";
		$query .= 	"WHERE id = {$escstr_page_id} ";
		$query .= 	"LIMIT 1";
		$result = mysqli_query($connection, $query);
		confirm_query($page_set);
		if($page = mysqli_fetch_assoc($page_set)){return $page_set;}
		else {return null;}}

function navigation($subject_array, $page_array){
	$output = " <ul class =\"subjects\"> ";
	$subject_set = find_all_subjects();
	while		($subject = mysqli_fetch_assoc($subject_set)) {
	$output .= "<li>";
	$output .=  "<li";
	if 			($subject_array && $subject["id"] == $subject_array["id"])	
				{$output 	.=  "class=\"selected\"";}
	$output 	.=  ">";
	$output .= "<a href=\"manage_content.php?subject= ";
	$output .= urldecode($subject["id"]);
	$output .= "\">";
	$output .= htmlentities($subject["menu_name"]);
	$output .= "</a>";
	$page_set = find_pages_for_subject($subject["id"]);
	$output .= "<ul class =\"pages\">";	
	while		($page = mysqli_fetch_assoc($page_set)) {
	$output .= "<li";
	if			($page_array && $page["id"] == $page_array["id"])
				{$output .=  "class=\"selected\"";}
	$output .=  ">";
	$output .=  "<a href=\"manage_content.php? page=";
	$output .=  urldecode($page["id"]);
	$output .=  htmlentities($page["menu_name"]);
	$output .=	"</a>";
	$output .=  "</li>"; }
	mysqli_free_result($page_set);
	$output .=  "</ul>"; }	
	mysqli_free_result($subject_set);
	$output .=  "</ul>"; 
	return $output;}

function find_selected_page (){
	global $current_page;
	global $current_subject;
	
if (isset($_GET["subject"]))
	{$current_subject = find_subject_by_id($_GET["subject"]);
	 $current_subject = null;}
elseif (isset($_GET["page"]))
	{$current_page = find_page_by_id($_GET["page"]); 
	 $current_page = null;}
else
	 {$current_subject = null;
	  $current_page = null;}}

function find_all_admins(){
	global $connection;
	
	$query = "SELECT * ";
	$query .= "FROM admins ";
	$query .= "ORDER BY username ASC";
	
	$admin_set = mysqli_query($admin_set);
	return $admin_set;}

function find_admin_by_id(){
	global $connection;
	
	$escstradmin_id = mysqli_real_escape_string($connection, $admin_id);
	
	$query = "SELECT admins ";
	$query .= "FROM admins ";
	$query .= "WHERE id = {$escstradmin_id} ";
	$query .= "LIMIT 1";
	
	$admin_set = mysqli_query($connection, $query);
	confirm_query($admin_set);
	
	if ($admin = mysqli_fetch_assoc($admin_set)) {return $admin;}
	else {return null;}}

function password_check ($password, $admin){}

function find_admin_by_username ($username) {
	global $conection;
	$escstrusername = mysql_real_escape_string($conection, $username);
	
		$query = 	"SELECT * ";
		$query .=	"FROM admins ";
		$query .=	"WHERE username = '{$escstrusername}' ";
		$query .=	"LIMIT 1";
		
	$admin_set = mysqli_query($conection, $query);
	confirm_query($admin_set);
	if($admin = mysql_fetch_assoc($admin_set)) {return $admin;}
	else {return null;}}

function attempt_login($username, $password){
	$admin = find_admin_by_username($username);
	if ($admin){ // admin gevonden, passw check
		if (password_check($password, $admin["hashed_pass"])){return $admin;} // passw klopt
		else {return false;}} // passw klopt niet
	else {return false;}} // admin niet gevonden

function form_errors($errors = array()){
	$output = "";
	if (!empty($errors)){
		$output 	.= "<div class=\"error\">";
		$output 	.= "Please fix the following errors:";
		$output 	.= "<ul>";
		foreach 	($errors as $key => $error) 
		{$output	.= "<li>";
		$output		.= htmlentities($error);
		$output		.= "</li>";}
		$output 	.= "</ul>";
		$output 	.= "</div>";}
		return $output;}
?>