<?php
$naam = "root";
$pass = "";
$dbnaam = "happy_cruise_lines";
$dblocatie = "localhost";

$connection = mysqli_connect($dblocatie, $naam, $pass, $dbnaam);
if(mysqli_connect_errno()){
	die("there was an error connection to database" . mysqli_connect_error());}
?>