<div id="footer">Eat-It
</div>
</body>
</html>
<?php
//close db connection
if (isset($connection)){mysqli_close($connection);} 
?>
