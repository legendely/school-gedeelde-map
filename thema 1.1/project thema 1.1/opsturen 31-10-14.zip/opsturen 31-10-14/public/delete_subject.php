<?php require_once ("session.php")?>
<?php require_once ("database_connect.php")?>
<?php require_once ("functions.php")?>

<?php 
	$current_subject = find_subject_by_id($_GET["subject"]);
	if (!$current_subject){
		redirect_to("manage_content.php");} 
	
	$id = $current_subject["id"];
	$query  = "DELETE FROM subjects ";
	$query .= "WHERE id = {$id} ";
	$query .= "LIMIT 1";
	$result = 	mysqli_query($connection, $query);
	
	if ($result && mysqli_effected_rows($connection) ==1){
			//sucsess
			$_SESSION["message"] = "Subject deleted";
			redirect_to("manage_content.php");}
	else 	//failure
			{$_SESSION["message"] = "Subject deletion failed";
			redirect_to("manage_content.php?subject={$id}");}
?>