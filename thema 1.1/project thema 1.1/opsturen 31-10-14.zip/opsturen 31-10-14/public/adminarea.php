<?php require_once ("functions.php")?>

	<h2>Admin Menu</h2>
	<p>Welkom bij de admin pagina, <?php echo htmlentities($_SESSION["username"]);?>. </p>
	<ul>
	<li> <a href="manage_content.php" > Manage Website Inhoud</a></li>
	<li> <a href="manage_admins.php" > Manage Admin Gebruikers</a></li>
	<li> <a href="manage_content.php" > Logout</a></li>
	</ul>