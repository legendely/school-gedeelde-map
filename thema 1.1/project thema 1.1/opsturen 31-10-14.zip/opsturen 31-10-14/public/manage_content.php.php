<?php require_once ("session.php")?>
<?php require_once ("database_connect.php")?>
<?php require_once ("functions.php")?>

<?php
find_selected_page();
?>

<div id="main">
	<div id="navigation">
			<a href="admin.php"> Main menu </a>
	<br/>
	<?php echo navigation($current_subject, $current_page); ?>

	<br/>
	<a	href="new_subject.php"> Add a subject </a>
</div>

<div id = "page">
	<?php echo message(); ?>
	<?php if ($current_subject){ ?>
	<h2>Manage Subject</h2>
	
	Menu name: <?php echo htmlentities($current_subject["menu_name"]); ?>
	<br/>
	Position: <?php echo $current_position["position"]; ?>
	<br/>
	Visible: <?php echo $current_subject["visible"] == 1 ? 'yes': 'no' ; ?>
	<br/>
	
	<a href="edit_subject.php?subject=<?php echo urldecode($current_subject["id"]); ?>" > Eddit Subject </a>
	
	<?php }elseif ($current_page){ ?>
	<h2>Manage Page</h2>
	Menu name: <?php echo $current_page["menu_name"]; ?>
	<br/>
	<?php }else 						{	?>
	please select a subject or a page.
	<?php 								}	?>
	
</div> </div>
