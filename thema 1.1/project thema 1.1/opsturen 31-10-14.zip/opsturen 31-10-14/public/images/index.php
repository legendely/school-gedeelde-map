<!DOCTYPE html>
<head>
	<title>index</title>
	
	<form action"" method="post">
		<input type="submit" name="pagina" value="basiclogin.php"/>
		<input type="submit" name="pagina" value="menuvandeweek.php" />
		<input type="submit" name="pagina" value="contacten.php" />
		<input type="submit" name="pagina" value="page4" />
	</form>

<link rel="stylesheet" type="text/css" href="opmaak.css">

</head>

<body>

	
<?php
if (isset($_POST["pagina"]))  	{$_SESSION["pagina"] = $_POST["pagina"];}
if (isset($_POST["pagina"]))  	{include_once $_POST["pagina"];}
?>
	
</body>
<footer>
	<p>gemaakt door: Marcel Stoepker. </p>
</footer>