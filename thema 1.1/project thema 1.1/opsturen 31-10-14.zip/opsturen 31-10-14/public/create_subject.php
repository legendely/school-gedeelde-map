<?php require_once ("session.php");?>
<?php require_once ("database_connect.php");?>
<?php require_once ("functions.php");?>
<?php require_once ("validation_unctions.php");?>


<?php
if (isset($_POST['submit'])) {
	//prosses form

	$menu_name 	= mysql_escstr($_POST["menu_name"]);
	$position 	= (int) $_POST["position"];
	$visible 	= (int) $_POST["visible"];
	
	if (!empty($errors)){
		$_SESSION["errors"] = $errors;
		redirect_to("new_subject.php");}
	else {
			$query  =	"INSERT INTO subjects ( ";
			$query .=	"menu_name, position, visible";
			$query .=	") VALUES ( ";
			$query .=	"'{$menu_name}', {$position}, {$visible}";
			$query .=	")";
			$result = mysqli_query($connection, $query);
	
		if ($result) 	{redirect_to("manage_content.php");
						$_SESSION["message"] = "Subject created";}
		else 			{redirect_to("new_subject.php");
						$_SESSION["message"] = "Subject creation failed";}}}

else {redirect_to("new_subject.php");}

?>

<?php if (isset($connection)){mysqli_close($connection);} ?>