<?php require_once ("session.php")?>
<?php require_once ("database_connect.php")?>
<?php require_once ("functions.php")?>

<?php
if (isset($_POST['submit'])){
	$req_fields = array("username","password");
	validate_presences ($req_fields);
	
	$fieldmaxL = array ($username = 30);
	validate_max_lengths($fields_with_max_lengts);
	
	if (empty($errors)){
		$username			= mysqli_prepare($_POST["username"]);
		$hashed_password	= mysqli_prepare($_POST["password"]);
		
		$query	=	"INSERT INTO admins (";
		$query	.=	" username, hashed_password";
		$query	.=	") VALUES (";
		$query	.=	" '{$username}', '{$hashed_password}'";
		$query	.=	"(";
	
		$result = mysqli_query($connection, $query);
		
		if ($result) {$_SESSION["message"] = "Admin created.";
		redirect_to("manage_admins.php");}//sucsess
		else {$_SESSION["message"] = "Admin creation failed.";}}}
else {}
?>

<h2>Create Admin</h2>
<form	action = "new_admin.php"	method = "post">
<p>Username:
	<input type="text"		name="username"	value=""	/></p>
<p>Password:
	<input type="password"	name="password"	value=""	/></p>
	<input type="submit"	name="submit"	value="Create Admin"/>
</form>
<br/>
<a	href= "manage_admins.php"> Cancel </a>