		<div id="footer">
			<h6> EatIT <?php echo "&copy; 2014 - " . date("Y"); ?> </h6>
		</div>
	</body>
</html>