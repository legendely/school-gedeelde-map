<?php
	//Includes en variabelen.
	$page = "Contact";
	include("../Includes/Layouts/header.php");
?>

<!-- Content van pagina -->
<div id="content">
	<h2> Contact: </h2>
	
</div>

<?php
	//Include footer.
	include("../Includes/Layouts/footer.php");
?>